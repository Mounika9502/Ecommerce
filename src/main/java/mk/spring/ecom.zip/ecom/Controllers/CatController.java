package mk.spring.ecom.Controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import mk.spring.ecom.Categories;

import mk.spring.ecom.Repositories.CatRepository;


@RestController
@RequestMapping("/api")
public class CatController {
	@Autowired
	CatRepository catRepository;
	
	@PostMapping("/Categories")
	public String createnewcategory(@RequestBody Categories cat) {
		catRepository.save(cat);
		return "New Category Created";
	}
	@GetMapping("/Categories")
	public ResponseEntity<List<Categories>> getAllCategories(){
		List<Categories> catlist=new ArrayList<>();
		catRepository.findAll().forEach(catlist::add);
		return new ResponseEntity<List<Categories>>(catlist,HttpStatus.OK);
	}
	@GetMapping("/Categories/{id}")
	public ResponseEntity<Categories> getuserbyId(@PathVariable Long id){
		Optional<Categories> user=catRepository.findById(id);
		if(user.isPresent()) {
			return new ResponseEntity<Categories>(user.get(),HttpStatus.FOUND);
		}
		else {
			return new ResponseEntity<Categories>(HttpStatus.NOT_FOUND);
		}
	}
	@PutMapping("/Categories/{id}")
	public String updateuserdetailsbyId(@PathVariable Long id,@RequestBody Categories cat) {
		Optional<Categories> exCat=catRepository.findById(id);
		if(exCat.isPresent()) {
			Categories updCat=exCat.get();
			updCat.setCatname(cat.getCatname());
			catRepository.save(updCat);
			return "Details of Category with id " + id + "are updated";
			
		}
		else {
			return "there is no Category with  id " + id;
		}
		
	}
	@DeleteMapping("/Categories/{id}")
	public String deletebyId(@PathVariable Long id) {
		catRepository.deleteById(id);
		return "Deleted the user with user id" + id;
	}
	@DeleteMapping("/Categories")
	public String deleteallUsers() {
		catRepository.deleteAll();
		return "All Categories are deleted";
	}
	

}

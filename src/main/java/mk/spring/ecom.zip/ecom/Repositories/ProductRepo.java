package mk.spring.ecom.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import mk.spring.ecom.Product;

public interface ProductRepo extends JpaRepository<Product, Integer>{

}